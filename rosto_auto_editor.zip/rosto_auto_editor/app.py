import os, json, re, subprocess, shutil, uuid
from pathlib import Path
from flask import Flask, render_template, request, jsonify, send_from_directory, abort
from werkzeug.utils import secure_filename

BASE = Path(__file__).resolve().parent
UPLOADS = BASE / "uploads"
OUTPUTS = BASE / "outputs"
WORK = BASE / "work"
for p in (UPLOADS, OUTPUTS, WORK): p.mkdir(exist_ok=True)
app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024 * 1024
ALLOWED = {".mp4", ".mov", ".mkv", ".webm", ".m4v"}
JOBS = {}

def run(cmd, timeout=None):
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, check=False)

def ffmpeg_available():
    return shutil.which("ffmpeg") is not None and shutil.which("ffprobe") is not None

def probe(path):
    p = run(["ffprobe", "-v", "error", "-show_entries",
             "format=duration:stream=codec_type,width,height",
             "-of", "json", str(path)])
    if p.returncode:
        raise RuntimeError("تعذّر قراءة الفيديو. تأكد من أن الملف فيديو صالح وأن FFmpeg مثبت.")
    data = json.loads(p.stdout or "{}")
    duration = float(data.get("format", {}).get("duration", 0) or 0)
    video = next((s for s in data.get("streams", []) if s.get("codec_type") == "video"), {})
    return {"duration": duration, "width": video.get("width"), "height": video.get("height")}

def scene_candidates(path, duration):
    # Scene-change timestamps from FFmpeg; fallback to regular short intervals.
    p = run(["ffmpeg", "-hide_banner", "-i", str(path), "-vf",
             "select='gt(scene,0.32)',showinfo", "-an", "-f", "null", "-"], timeout=180)
    times = [0.0]
    for line in (p.stderr or "").splitlines():
        m = re.search(r"pts_time:([0-9.]+)", line)
        if m:
            t = float(m.group(1))
            if t > 1.5 and t < duration - 1.0 and all(abs(t-x) > 2.5 for x in times):
                times.append(t)
    times = sorted(times)
    if len(times) < 3:
        step = max(6.0, min(12.0, duration / 8 if duration else 8))
        times = [float(x) for x in range(0, int(duration), int(step) or 6)]
    clips = []
    for i, start in enumerate(times):
        end = min(duration, (times[i+1] if i+1 < len(times) else duration))
        if end - start >= 2.0:
            # Trim extremely long scenes into useful review-sized suggestions.
            if end - start > 18:
                end = start + 12
            clips.append({"id": len(clips)+1, "start": round(start, 2), "end": round(end, 2),
                          "duration": round(end-start, 2), "selected": True,
                          "label": f"لقطة {len(clips)+1}", "reason": "اقتراح تلقائي حسب تغيّر المشهد"})
    return clips[:60]

def transcribe(path, jobdir):
    try:
        from faster_whisper import WhisperModel
        model_name = os.getenv("WHISPER_MODEL", "small")
        # CPU-friendly quantization; model files download on first run.
        model = WhisperModel(model_name, device="cpu", compute_type="int8")
        segments, info = model.transcribe(str(path), language="ar", vad_filter=True,
                                          word_timestamps=False, beam_size=5)
        out = []
        for s in segments:
            txt = (s.text or "").strip()
            if txt:
                out.append({"start": round(float(s.start), 2), "end": round(float(s.end), 2), "text": txt})
        (jobdir / "transcript.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
        return {"status": "ok", "language": getattr(info, "language", "ar"), "segments": out}
    except ImportError:
        return {"status": "unavailable", "message": "ميزة التفريغ تحتاج تثبيت faster-whisper. يمكنك تثبيتها من requirements-ai.txt."}
    except Exception as e:
        return {"status": "error", "message": f"تعذّر إنشاء الترجمة: {str(e)[:250]}"}

def srt_time(seconds):
    ms = int(round(seconds * 1000))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02}:{m:02}:{s:02},{ms:03}"

def write_srt(segments, path):
    with open(path, "w", encoding="utf-8-sig") as f:
        for i, seg in enumerate(segments, 1):
            f.write(f"{i}\n{srt_time(seg['start'])} --> {srt_time(seg['end'])}\n{seg['text']}\n\n")

@app.get("/")
def index():
    return render_template("index.html")

@app.get("/api/health")
def health():
    return jsonify({"ffmpeg": ffmpeg_available(), "whisper": __import__("importlib").util.find_spec("faster_whisper") is not None})

@app.post("/api/upload")
def upload():
    if not ffmpeg_available():
        return jsonify({"error": "FFmpeg غير مثبت. ثبّته أولًا ثم أعد تشغيل التطبيق."}), 503
    f = request.files.get("video")
    if not f or not f.filename:
        return jsonify({"error": "اختر ملف فيديو أولًا."}), 400
    ext = Path(secure_filename(f.filename)).suffix.lower()
    if ext not in ALLOWED:
        return jsonify({"error": "الصيغ المدعومة: MP4 وMOV وMKV وWEBM."}), 400
    jid = uuid.uuid4().hex[:12]
    path = UPLOADS / f"{jid}{ext}"
    f.save(path)
    try:
        meta = probe(path)
        if meta["duration"] <= 0:
            raise RuntimeError("مدة الفيديو غير صالحة.")
    except Exception as e:
        path.unlink(missing_ok=True)
        return jsonify({"error": str(e)}), 400
    jobdir = WORK / jid
    jobdir.mkdir(exist_ok=True)
    clips = scene_candidates(path, meta["duration"])
    JOBS[jid] = {"path": path, "meta": meta, "clips": clips, "transcript": [], "music": None}
    return jsonify({"id": jid, "name": f.filename, "meta": meta, "clips": clips})

@app.post("/api/analyze/<jid>")
def analyze(jid):
    job = JOBS.get(jid)
    if not job: return jsonify({"error": "لم يتم العثور على المشروع."}), 404
    result = transcribe(job["path"], WORK / jid)
    if result.get("status") == "ok":
        job["transcript"] = result["segments"]
    return jsonify(result)

@app.post("/api/music/<jid>")
def music(jid):
    job = JOBS.get(jid)
    if not job: return jsonify({"error": "المشروع غير موجود."}), 404
    f = request.files.get("music")
    if not f or not f.filename: return jsonify({"error": "اختر ملف موسيقى."}), 400
    ext = Path(secure_filename(f.filename)).suffix.lower()
    if ext not in {".mp3", ".wav", ".m4a", ".aac", ".ogg"}:
        return jsonify({"error": "صيغة الموسيقى غير مدعومة."}), 400
    path = WORK / jid / ("music" + ext)
    f.save(path)
    job["music"] = path
    return jsonify({"ok": True, "name": f.filename})

@app.post("/api/export/<jid>")
def export_video(jid):
    job = JOBS.get(jid)
    if not job: return jsonify({"error": "المشروع غير موجود."}), 404
    body = request.get_json(silent=True) or {}
    chosen = body.get("clips", [])
    if not chosen:
        return jsonify({"error": "اختر لقطة واحدة على الأقل."}), 400
    try:
        clips = sorted([(max(0.0, float(c["start"])), min(job["meta"]["duration"], float(c["end"])))
                        for c in chosen if float(c["end"]) > float(c["start"])], key=lambda x:x[0])
    except Exception:
        return jsonify({"error": "قائمة اللقطات غير صالحة."}), 400
    if not clips: return jsonify({"error": "لا توجد لقطات صالحة."}), 400

    jid_out = uuid.uuid4().hex[:10]
    out = OUTPUTS / f"rosto_{jid_out}.mp4"
    workdir = WORK / jid
    pieces = []
    # Render each selected section to the same vertical canvas; then concatenate.
    for i, (start, end) in enumerate(clips):
        part = workdir / f"part_{i:03}.mp4"
        vf = ("scale=1080:1920:force_original_aspect_ratio=increase,"
              "crop=1080:1920,setsar=1, fps=30,format=yuv420p")
        cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-ss", str(start),
               "-i", str(job["path"]), "-t", str(end-start), "-vf", vf,
               "-c:v", "libx264", "-preset", "veryfast", "-crf", "21",
               "-c:a", "aac", "-b:a", "160k", "-ar", "48000", "-ac", "2", str(part)]
        p = run(cmd, timeout=900)
        if p.returncode != 0 or not part.exists() or part.stat().st_size == 0:
            return jsonify({"error": "فشل تجهيز إحدى اللقطات: " + (p.stderr or "")[-350:]}), 500
        pieces.append(part)
    concatfile = workdir / "concat.txt"
    concatfile.write_text("".join("file '" + str(p).replace("'", "'\\''") + "'\n" for p in pieces), encoding="utf-8")
    joined = workdir / "joined.mp4"
    p = run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-f", "concat", "-safe", "0",
             "-i", str(concatfile), "-c", "copy", str(joined)], timeout=900)
    if p.returncode or not joined.exists():
        return jsonify({"error": "فشل جمع اللقطات: " + (p.stderr or "")[-350:]}), 500

    # Build subtitles clipped to selected source intervals and remap timestamps to the joined timeline.
    mapped = []
    cursor = 0.0
    for start, end in clips:
        for seg in job["transcript"]:
            a, b = max(start, seg["start"]), min(end, seg["end"])
            if b > a:
                mapped.append({"start": cursor + a-start, "end": cursor + b-start, "text": seg["text"]})
        cursor += end-start
    subtitle_path = workdir / "captions.srt"
    write_srt(mapped, subtitle_path)
    # Use subtitles filter; font fallback varies by OS. Audio is kept original; optional music is mixed quietly.
    sub_filter = "subtitles=" + str(subtitle_path).replace("\\", "/").replace(":", "\\:").replace("'", "\\'")
    vf = f"{sub_filter}:force_style='FontName=Arial,FontSize=20,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,BorderStyle=1,Outline=3,Shadow=1,Alignment=2,MarginV=150'"
    finaltmp = workdir / "final.mp4"
    if job.get("music"):
        cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", str(joined), "-stream_loop", "-1",
               "-i", str(job["music"]), "-filter_complex",
               f"[0:a]volume=1.0[voice];[1:a]volume=0.12[music];[voice][music]amix=inputs=2:duration=first:dropout_transition=2[a]",
               "-vf", vf, "-map", "0:v:0", "-map", "[a]", "-c:v", "libx264", "-preset", "veryfast",
               "-crf", "20", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", str(finaltmp)]
    else:
        cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", str(joined),
               "-vf", vf, "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
               "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", str(finaltmp)]
    p = run(cmd, timeout=1800)
    if p.returncode != 0 or not finaltmp.exists() or finaltmp.stat().st_size == 0:
        return jsonify({"error": "فشل التصدير: " + (p.stderr or "")[-500:]}), 500
    # Verify actual output file and stream metadata before claiming success.
    try:
        finalmeta = probe(finaltmp)
        if finalmeta["width"] != 1080 or finalmeta["height"] != 1920:
            raise RuntimeError("الدقة النهائية ليست 1080×1920.")
        if finalmeta["duration"] <= 0: raise RuntimeError("مدة الملف النهائي غير صالحة.")
    except Exception as e:
        return jsonify({"error": "تم إنشاء ملف لكن فشل التحقق منه: " + str(e)}), 500
    shutil.copy2(finaltmp, out)
    return jsonify({"ok": True, "url": f"/outputs/{out.name}", "name": out.name,
                    "bytes": out.stat().st_size, "meta": finalmeta,
                    "message": "اكتمل التصدير والتحقق من وجود الملف ودقته."})

@app.get("/outputs/<path:name>")
def output_file(name):
    if not re.fullmatch(r"rosto_[a-f0-9]+\.mp4", name): abort(404)
    return send_from_directory(OUTPUTS, name, as_attachment=True, download_name=name)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=False)
