let jobId=null, clipData=[];
const $=id=>document.getElementById(id);
const videoInput=$("video"), drop=$("drop");
videoInput.addEventListener("change",()=>{$("fileName").textContent=videoInput.files[0]?.name||""});
["dragenter","dragover"].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.style.borderColor="#a78bfa"}));
["dragleave","drop"].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.style.borderColor=""}));
drop.addEventListener("drop",e=>{if(e.dataTransfer.files.length){videoInput.files=e.dataTransfer.files;$("fileName").textContent=videoInput.files[0].name}});
function fmt(s){s=Math.max(0,Math.floor(s));return `${Math.floor(s/60)}:${String(s%60).padStart(2,"0")}`}
function status(id,msg){$(id).textContent=msg}
$("uploadBtn").onclick=async()=>{
 const f=videoInput.files[0]; if(!f){status("status","اختر فيديو أولًا");return}
 $("uploadBtn").disabled=true;status("status","جارٍ فحص الفيديو واكتشاف تغيّرات المشهد…");
 try{
  const fd=new FormData();fd.append("video",f);
  const r=await fetch("/api/upload",{method:"POST",body:fd});const d=await r.json();if(!r.ok)throw Error(d.error||"فشل الرفع");
  jobId=d.id;clipData=d.clips;
  $("preview").src=URL.createObjectURL(f);$("videoArea").classList.remove("hidden");
  $("meta").textContent=`المدة ${fmt(d.meta.duration)} • ${d.meta.width}×${d.meta.height} • ${clipData.length} اقتراح لقطة`;
  renderClips();$("clipsPanel").classList.remove("hidden");$("exportPanel").classList.remove("hidden");
  status("status","اكتمل التحليل الأولي. راجع اللقطات أدناه.");
 }catch(e){status("status",e.message)}finally{$("uploadBtn").disabled=false}
};
function renderClips(){
 $("clips").innerHTML="";
 clipData.forEach((c,i)=>{
  const el=document.createElement("div");el.className="clip";
  el.innerHTML=`<input type="checkbox" ${c.selected?"checked":""} aria-label="اختيار اللقطة"><div class="clip-main"><div class="clip-title">${c.label}</div><div class="clip-sub">${fmt(c.start)} – ${fmt(c.end)} • ${c.duration.toFixed(1)} ثانية</div></div><button type="button">معاينة</button>`;
  el.querySelector("input").onchange=e=>clipData[i].selected=e.target.checked;
  el.querySelector("button").onclick=()=>{$("preview").currentTime=c.start;$("preview").play()};
  $("clips").appendChild(el);
 });
}
$("transcribeBtn").onclick=async()=>{
 if(!jobId)return;$("transcribeBtn").disabled=true;status("transcriptStatus","قد يستغرق هذا بعض الوقت، خصوصًا عند أول تشغيل…");
 try{const r=await fetch(`/api/analyze/${jobId}`,{method:"POST"});const d=await r.json();
 if(d.status!=="ok"){status("transcriptStatus",d.message||d.error||"تعذّرت الترجمة");return}
 $("transcriptBox").innerHTML=d.segments.map(s=>`<p><b>${fmt(s.start)}</b> — ${escapeHtml(s.text)}</p>`).join("")||"لم يُكتشف كلام واضح.";
 $("transcriptBox").classList.remove("hidden");status("transcriptStatus",`تم إنشاء ${d.segments.length} مقطع ترجمة. راجعها بعد التصدير.`);
 }catch(e){status("transcriptStatus",e.message)}finally{$("transcribeBtn").disabled=false}
};
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
$("exportBtn").onclick=async()=>{
 if(!jobId)return;
 const selected=clipData.filter(c=>c.selected);if(!selected.length){status("exportStatus","حدد لقطة واحدة على الأقل");return}
 $("exportBtn").disabled=true;status("exportStatus","جارٍ تجهيز الفيديو وتصديره… لا تغلق الصفحة");
 try{
  const music=$("music").files[0];
  if(music){const fd=new FormData();fd.append("music",music);const mr=await fetch(`/api/music/${jobId}`,{method:"POST",body:fd});const md=await mr.json();if(!mr.ok)throw Error(md.error||"تعذّر رفع الموسيقى")}
  const r=await fetch(`/api/export/${jobId}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({clips:selected})});
  const d=await r.json();if(!r.ok)throw Error(d.error||"فشل التصدير");
  $("result").innerHTML=`<strong>✓ ${escapeHtml(d.message)}</strong><br>الدقة: ${d.meta.width}×${d.meta.height} • المدة: ${fmt(d.meta.duration)} • الحجم: ${(d.bytes/1048576).toFixed(1)} MB<br><a href="${d.url}">تحميل الفيديو النهائي MP4</a>`;
  $("result").classList.remove("hidden");status("exportStatus","اكتمل التصدير والتحقق بنجاح.");
 }catch(e){status("exportStatus",e.message)}finally{$("exportBtn").disabled=false}
};
